package com.example.skincare.Prevalent;

import com.example.skincare.Model.Users;

public class Prevalent {
    public static Users currentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
